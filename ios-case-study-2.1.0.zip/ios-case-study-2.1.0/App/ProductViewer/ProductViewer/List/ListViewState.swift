//
//  ListViewState.swift
//  ProductViewer
//
//  Copyright © 2016 Target. All rights reserved.
//

import Tempo

/// List view state
struct ListViewState: TempoViewState, TempoSectionedViewState {
    var listItems: [TempoViewStateItem]
    
    var sections: [TempoViewStateItem] {
        return listItems
    }
}

class ProductList: Codable {
    let products: [ListItem]?
    required init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        products = try values.decodeIfPresent([ListItem].self, forKey: .products)
    }
}

/// View state for each list item.
struct ListItem: TempoViewStateItem, Codable, Equatable, Identifiable {
    let id: Int?
    let title: String?
    let price: String?
    let aisle: String?
    let description: String?
    let image_url: String?
}


func ==(lhs: ListItem, rhs: ListItem) -> Bool {
    return lhs.title == rhs.title
        && lhs.price == rhs.price
}
