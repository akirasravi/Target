//
//  ListCoordinator.swift
//  ProductViewer
//
//  Copyright © 2016 Target. All rights reserved.
//

import Foundation
import Tempo
import SwiftUI
/*
 Coordinator for the product list
 */
class ListCoordinator: TempoCoordinator {
    
    // MARK: Presenters, view controllers, view state.
    
    var presenters = [TempoPresenterType]() {
        didSet {
            updateUI()
        }
    }
    
    fileprivate var viewState: ListViewState {
        didSet {
            updateUI()
        }
    }
    
    fileprivate func updateUI() {
        for presenter in presenters {
            presenter.present(viewState)
        }
    }
    
    let dispatcher = Dispatcher()
    
    lazy var viewController: ListViewController = {
        return ListViewController.viewControllerFor(coordinator: self)
    }()
    
    // MARK: Init
    
    required init() {
        viewState = ListViewState(listItems: [])
        updateState()
        registerListeners()
    }
    
    // MARK: ListCoordinator
    
    fileprivate func registerListeners() {
        dispatcher.addObserver(ListItemPressed.self) { [weak self] e in
           
            TargetServicesMock().getDealDetails(id: "") { (state, error) in
                if let state = state {
                    DispatchQueue.main.async { [weak self] in
                        let vc = UIHostingController(rootView: DetailsView(details: state))
                        self?.viewController.present(vc, animated: true, completion: nil)
                    }
                }else {
                    DispatchQueue.main.async { [weak self] in
                        let alert = UIAlertController(title: "api error", message: error.debugDescription, preferredStyle: .alert)
                        alert.addAction( UIAlertAction(title: "OK", style: .cancel, handler: nil) )
                        self?.viewController.present(alert, animated: true, completion: nil)
                    }
                }
            }
        }
    }
    
    func updateState() {
        TargetServicesMock.shared.getDeals(){ [weak self] (deals,error) in
            if deals != nil {
                //self?.viewState.listItems = deals?.products ?? []
            }
            
        }
//        viewState.listItems = (1..<10).map { index in
//            ListItemViewState(title: "Puppies!!!", price: "$9.99", image: UIImage(named: "\(index)"))
//        }
    }
}
