//
//  ProductListComponent.swift
//  ProductViewer
//
//  Copyright © 2016 Target. All rights reserved.
//

import Tempo

struct ProductListComponent: Component {
    var dispatcher: Dispatcher?

    func prepareView(_ view: ProductListView, item: ListItem) {
        // Called on first view or ProductListView
    }
    
    func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }
    
    func configureView(_ view: ProductListView, item: ListItem) {
        view.titleLabel.text = item.title
       // view.priceLabel.text = item.regular_price?.display_string
        if let urlString = item.image_url {
            let url = URL(string: urlString)

            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: url!) {
                    DispatchQueue.main.async {
                        view.productImage.image = UIImage(data: data)
                    }
                }else  {
                    DispatchQueue.main.async {
                        view.productImage.image = UIImage(named: "1")
                    }
                }
            }
        }
        
        
    }
    
    func selectView(_ view: ProductListView, item: ListItem) {
        dispatcher?.triggerEvent(ListItemPressed(item: item))
    }
}

extension ProductListComponent: HarmonyLayoutComponent {
    func heightForLayout(_ layout: HarmonyLayout, item: TempoViewStateItem, width: CGFloat) -> CGFloat {
        return 100.0
    }
}
