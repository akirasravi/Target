//
//  DealListView.swift
//  ProductViewer
//
//  Created by Ravi Chandra Sekhar SARIKA on 04/04/21.
//  Copyright © 2021 Target. All rights reserved.
//

import SwiftUI

struct DealListView: View {
    @State var products: [DealListItem] = []
    var body: some View {
        NavigationView {
            if products.count == 0 {
                Text("no Deals")
            }else {
                ScrollView {
                    LazyVStack {
                        ForEach(products) { product in
                            NavigationLink(destination: DetailsView(details: product)) {
                                DealItemView(product: product).frame(height: 100).border(Color.gray, width: 0.5).padding(3)
                            }.buttonStyle(PlainButtonStyle())
                        }
                    }.listStyle(GroupedListStyle()).onAppear {
                        UITableView.appearance().separatorStyle = .none
                    }
                }
                .navigationTitle("Deals").navigationViewStyle(DoubleColumnNavigationViewStyle())
            }
        }.onAppear {
            TargetServicesMock.shared.getDeals { (productList, error) in
                if let productList = productList {
                    products = productList.products ?? []
                }
            }
        }
    }
}

struct ProductListSwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        DealListView()
    }
}
