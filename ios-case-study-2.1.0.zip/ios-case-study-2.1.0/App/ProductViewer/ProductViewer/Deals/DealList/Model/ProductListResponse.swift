//
//  ProductList.swift
//  ProductViewer
//
//  Created by Ravi Chandra Sekhar SARIKA on 04/04/21.
//  Copyright © 2021 Target. All rights reserved.
//

import Foundation
struct DealsListResponse: Codable {
    let products: [DealListItem]?
}

/// View state for each list item.
struct DealListItem: Codable, Identifiable {
    let id: Int?
    let title: String?
    let price: String?
    let aisle: String?
    let description: String?
    let image_url: String?
    let regular_price: Price?
    let sale_price: Price?
}

struct Price: Codable {
    let amount_in_cents: Int?
    let currency_symbol: String?
    let display_string: String?
}
