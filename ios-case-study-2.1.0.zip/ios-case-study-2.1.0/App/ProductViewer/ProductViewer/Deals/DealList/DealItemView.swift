//
//  DealItemView.swift
//  ProductViewer
//
//  Created by Ravi Chandra Sekhar SARIKA on 04/04/21.
//  Copyright © 2021 Target. All rights reserved.
//

import SwiftUI

struct DealItemView: View {
    @State var product: DealListItem
    var body: some View {
        GeometryReader { metrics in
            HStack {
                ImageView(withURL: product.image_url ?? "").aspectRatio(contentMode: .fit)
                VStack(alignment: .leading)  {
                    Text(product.title ?? "")
                    Divider().background(Color.gray)
                    HStack {
                        Text(product.regular_price?.display_string ?? "").lineLimit(nil)
                        if let aisle = product.aisle {
                            Spacer()
                            ZStack {
                              Circle()
                                .stroke(Color.gray, lineWidth: 1)
                              
                                Text(aisle).foregroundColor(.red)
                            }.frame(width: 40, height: 40).padding(.trailing, 16)
                            
                        }
                    }
                }
            }
        }
    }
}

struct ProductListItemView_Previews: PreviewProvider {
    static var previews: some View {
        let product = Bundle.main.decode(DealListItem.self, from: "dealDetails.json")
        DealItemView(product: product)
    }
}


