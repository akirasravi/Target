//
//  Services.swift
//  ProductViewer
//
//  Created by Ravi Chandra Sekhar SARIKA on 01/04/21.
//  Copyright © 2021 Target. All rights reserved.
//

import Foundation

protocol TargetServicesProtocol {
    func getDeals(completion: @escaping (DealsListResponse?, Error?) -> Void)
    func getDealDetails(id:String, completion: @escaping (DealListItem?, Error?) -> Void)
}

class TargetServices: TargetServicesProtocol {
    let session = URLSession.shared
    var endPointURL = "https://api.target.com/mobile_case_study_deals/v1"
    func getDealDetails(id: String, completion: @escaping (DealListItem?, Error?) -> Void) {
        let url = URL(string: endPointURL + "/deals/" + id)!
        
        let task = session.dataTask(with: url, completionHandler: { data, response, error in
            do {
                if let data = data {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? DealListItem {
                        completion(json, nil)
                    }else {
                        completion(nil, error)
                    }
                } else {
                    completion(nil, error)
                }
                
            } catch let error as NSError {
                completion(nil,error)
                print("Failed to load: \(error.localizedDescription)")
            }
        })
        
        task.resume()
    
    }
    
    static let shared = TargetServices()

    func getDeals(completion: @escaping (DealsListResponse?, Error?) -> Void) {
        let url = URL(string: endPointURL + "/deals")!
        
        let task = session.dataTask(with: url, completionHandler: { data, response, error in
            do {
                if let data = data {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? DealsListResponse{
                        completion(json, nil)
                    }else {
                        completion(nil, error)
                    }
                } else {
                    completion(nil, error)
                }
                
            } catch let error as NSError {
                completion(nil,error)
                print("Failed to load: \(error.localizedDescription)")
            }
        })
        
        task.resume()
    }
    
}


class TargetServicesMock: TargetServicesProtocol {
    static let shared = TargetServicesMock()
    func getDeals(completion: @escaping (DealsListResponse?, Error?) -> Void) {
        let products = Bundle.main.decode(DealsListResponse.self, from: "deals.json")
        completion(products, nil)
    }

    func getDealDetails(id: String, completion: @escaping (DealListItem?, Error?) -> Void) {
        let products = Bundle.main.decode(DealListItem.self, from: "dealDetails.json")
        completion(products, nil)
    }
    
    
}
