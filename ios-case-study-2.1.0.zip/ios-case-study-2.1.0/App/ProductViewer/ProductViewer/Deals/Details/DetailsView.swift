//
//  DetailsView.swift
//  ProductViewer
//
//  Created by Ravi Chandra Sekhar SARIKA on 03/04/21.
//  Copyright © 2021 Target. All rights reserved.
//

import SwiftUI

struct DetailsView: View {
    @State var details: DealListItem
    
    var body: some View {
        GeometryReader { metrics in
            let screenwidth = metrics.size.width - 16
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 10) {
                    ImageView(withURL: details.image_url ?? "")
                        .aspectRatio(contentMode: .fill).fixedSize(horizontal: true, vertical: true).frame(width: screenwidth+16, alignment: .center)
                    
                    Text(details.regular_price?.display_string ?? "").font(.system(size: 60)).fixedSize(horizontal: false, vertical: true)
                        .frame(width: screenwidth,alignment: .leading)
                    
                    Text(details.description ?? "").font(.system(size: 24)).fontWeight(.regular).lineLimit(nil)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(width: screenwidth)
                    
                    Spacer()
                    
                    Button(action: addToCartClicked) {
                               Text("add to cart")
                                   .frame(minWidth: 0, maxWidth: .infinity).padding(10)
                                .background(Color.red).foregroundColor(.white)
                    }
                    
                    Button(action: addToListClicked) {
                               Text("add to list")
                                   .frame(minWidth: 0, maxWidth: .infinity).padding(10)
                                .background(Color.gray).foregroundColor(.black)
                    }
                    
                }
            }.padding(8)
        }
   
    }
    
    func addToCartClicked() {
        
    }
    
    func addToListClicked() {
        
    }
}

struct DetailsView_Previews: PreviewProvider {
    static var previews: some View {
        DetailsView(details: DealListItem(id: 1, title:"ravi", price: "11", aisle: "", description:"adsad", image_url: "dasdas", regular_price: nil, sale_price: nil))
    }
}
