//
//  Tempo.h
//  Tempo
//
//  Copyright © 2016 Target. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Tempo.
FOUNDATION_EXPORT double TempoVersionNumber;

//! Project version string for Tempo.
FOUNDATION_EXPORT const unsigned char TempoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Tempo/PublicHeader.h>
